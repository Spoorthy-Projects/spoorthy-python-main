 #!/bin/bash
 aws s3 cp /home/centos/uname-output.log s3://spoorthy-us-east-1-rnd/uname.log
